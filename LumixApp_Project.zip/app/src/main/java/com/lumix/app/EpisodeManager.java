package com.lumix.app;

import android.content.Context;

import java.io.File;

public class EpisodeManager {
    private Context ctx;

    public EpisodeManager(Context ctx) {
        this.ctx = ctx;
    }

    public String getNextForPath(String currentPath) {
        File f = new File(currentPath);
        File dir = f.getParentFile();
        if (dir == null || !dir.isDirectory()) return null;

        VideoScanner scanner = new VideoScanner(ctx);
        VideoItem cur = scanner.parseFromFilename(f);
        if (!cur.isSeries()) return null;

        int nextEpisode = cur.getEpisode() + 1;
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File candidate : files) {
            String name = candidate.getName().toLowerCase();
            if (!candidate.isFile()) continue;
            if (name.matches(".*[sS]" + String.format("%02d", cur.getSeason()) + "[eE]" + String.format("%02d", nextEpisode) + ".*"))
                return candidate.getAbsolutePath();
            if (name.matches(".*" + cur.getSeason() + "x" + nextEpisode + ".*"))
                return candidate.getAbsolutePath();
            if (name.contains("episode" + nextEpisode) || name.contains("ep" + nextEpisode)) return candidate.getAbsolutePath();
        }
        return null;
    }
}
