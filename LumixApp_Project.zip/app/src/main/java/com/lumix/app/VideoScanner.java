package com.lumix.app;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoScanner {
    private Context ctx;

    public VideoScanner(Context ctx) {
        this.ctx = ctx;
    }

    public List<VideoItem> scanStorageForVideos() {
        List<VideoItem> out = new ArrayList<>();
        File root = Environment.getExternalStorageDirectory();
        scanRecursive(root, out);
        return out;
    }

    private void scanRecursive(File dir, List<VideoItem> out) {
        if (dir == null || !dir.exists() || !dir.isDirectory()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                scanRecursive(f, out);
            } else {
                String name = f.getName().toLowerCase();
                if (name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".avi") || name.endsWith(".mov")) {
                    VideoItem vi = parseFromFilename(f);
                    out.add(vi);
                }
            }
        }
    }

    public VideoItem parseFromFilename(File f) {
        String name = f.getName();
        VideoItem vi = new VideoItem();
        vi.setPath(f.getAbsolutePath());
        vi.setFilename(name);

        Pattern p = Pattern.compile(".*(19\\d{2}|20\\d{2}).*");
        Matcher m = p.matcher(name);
        if (m.find()) {
            vi.setYear(m.group(1));
        }

        Pattern s = Pattern.compile("[sS](\\d{1,2})[eE](\\d{1,2})");
        Matcher ms = s.matcher(name);
        if (ms.find()) {
            vi.setSeries(true);
            vi.setSeason(Integer.parseInt(ms.group(1)));
            vi.setEpisode(Integer.parseInt(ms.group(2)));
        } else {
            Pattern s2 = Pattern.compile("(\\d{1,2})x(\\d{1,2})");
            Matcher ms2 = s2.matcher(name);
            if (ms2.find()) {
                vi.setSeries(true);
                vi.setSeason(Integer.parseInt(ms2.group(1)));
                vi.setEpisode(Integer.parseInt(ms2.group(2)));
            }
        }

        String title = name.replaceAll("\\.(1080p|720p|x264|x265|bluray|web[-_ ]?dl|hdrip|dvd|hq|brrip)"," ");
        title = title.replaceAll("[._\\-]"," ").replaceAll("\\s+"," ").trim();
        vi.setSuggestedTitle(title);
        return vi;
    }
}
