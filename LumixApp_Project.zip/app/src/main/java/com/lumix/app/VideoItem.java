package com.lumix.app;

public class VideoItem {
    private String path;
    private String filename;
    private String suggestedTitle;
    private String year;
    private boolean isSeries = false;
    private int season = 0;
    private int episode = 0;
    private boolean recognized = false;

    public String getPath() { return path; }
    public void setPath(String p) { path = p; }

    public String getFilename() { return filename; }
    public void setFilename(String f) { filename = f; }

    public String getSuggestedTitle() { return suggestedTitle; }
    public void setSuggestedTitle(String s) { suggestedTitle = s; }

    public String getYear() { return year; }
    public void setYear(String y) { year = y; }

    public boolean isSeries() { return isSeries; }
    public void setSeries(boolean s) { isSeries = s; }

    public int getSeason() { return season; }
    public void setSeason(int s) { season = s; }

    public int getEpisode() { return episode; }
    public void setEpisode(int e) { episode = e; }

    public boolean isRecognized() { return recognized; }
    public void setRecognized(boolean r) { recognized = r; }
}
