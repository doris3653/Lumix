package com.lumix.app;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.lumix.app.databinding.ActivityPlayerBinding;

public class VideoPlayerActivity extends AppCompatActivity {
    private ActivityPlayerBinding binding;
    private VideoView videoView;
    private EpisodeManager episodeManager;
    private String currentPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityPlayerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        videoView = binding.videoView;
        episodeManager = new EpisodeManager(this);

        String path = getIntent().getDataString();
        if (path == null) path = getIntent().getStringExtra("video_item_path");
        currentPath = path;

        playPath(currentPath);
    }

    private void playPath(String path) {
        try {
            videoView.setVideoURI(Uri.parse(path));
            MediaController mc = new MediaController(this);
            mc.setAnchorView(videoView);
            videoView.setMediaController(mc);

            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    String next = episodeManager.getNextForPath(currentPath);
                    if (next != null) {
                        currentPath = next;
                        playPath(next);
                    } else {
                        Toast.makeText(VideoPlayerActivity.this, "Nincs több rész", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
            });

            videoView.start();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Nem lehet lejátszani: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
