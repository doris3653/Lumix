package com.lumix.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class VideoItemAdapter extends RecyclerView.Adapter<VideoItemAdapter.VH> {

    public interface OnItemClickListener {
        void onItemClick(VideoItem item);
    }

    private List<VideoItem> items;
    private OnItemClickListener listener;

    public VideoItemAdapter(List<VideoItem> items, OnItemClickListener l) {
        this.items = items;
        this.listener = l;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        VideoItem it = items.get(position);
        holder.title.setText(it.getSuggestedTitle());
        String tag = it.isSeries() ? "[S] " + it.getSeason() + "x" + it.getEpisode() : "[F]";
        holder.tag.setText(tag);
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(it);
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, tag;
        VH(View v) {
            super(v);
            title = v.findViewById(R.id.itemTitle);
            tag = v.findViewById(R.id.itemTag);
        }
    }
}
