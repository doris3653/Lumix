package com.lumix.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.lumix.app.databinding.ActivityFileBrowserBinding;

import java.util.ArrayList;
import java.util.List;

public class FileBrowserActivity extends AppCompatActivity implements VideoItemAdapter.OnItemClickListener {

    private ActivityFileBrowserBinding binding;
    private VideoItemAdapter adapter;
    private List<VideoItem> items = new ArrayList<>();
    private VideoScanner scanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityFileBrowserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adapter = new VideoItemAdapter(items, this);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this));
        binding.recycler.setAdapter(adapter);

        scanner = new VideoScanner(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
        } else {
            loadFiles();
        }

        binding.buttonRescan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { loadFiles(); }
        });
    }

    private void loadFiles() {
        items.clear();
        List<VideoItem> found = scanner.scanStorageForVideos();
        items.addAll(found);
        adapter.notifyDataSetChanged();
        Toast.makeText(this, items.size() + " videó találat", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemClick(VideoItem item) {
        Intent i = new Intent(this, VideoPlayerActivity.class);
        i.setData(Uri.parse(item.getPath()));
        i.putExtra("video_item_path", item.getPath());
        startActivity(i);
    }
}
