package com.lumix.app;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class MetadataFetcher {

    public static class Candidate {
        public String title;
        public String year;
        public String overview;
        public String posterUrl;

        public Candidate(String t, String y, String o, String p) {
            title = t; year = y; overview = o; posterUrl = p;
        }
    }

    private Context ctx;

    public MetadataFetcher(Context ctx) { this.ctx = ctx; }

    public List<Candidate> fetchCandidates(VideoItem item) {
        List<Candidate> out = new ArrayList<>();
        out.add(new Candidate(item.getSuggestedTitle(), item.getYear() == null ? "2023" : item.getYear(),
                "Rövid leírás a javaslatról.", null));
        out.add(new Candidate(item.getSuggestedTitle() + " (alt 1)", "2022", "Alternatív találat.", null));
        out.add(new Candidate(item.getSuggestedTitle() + " (alt 2)", "2021", "Alternatív találat.", null));
        return out;
    }
}
